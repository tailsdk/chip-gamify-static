const t=""+new URL("../assets/z3-built.CwlPURhO.wasm",import.meta.url).href;export{t as default};
