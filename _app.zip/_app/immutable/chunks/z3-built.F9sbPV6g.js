const t=""+new URL("../assets/z3-built.DWec-2dB.js",import.meta.url).href;export{t as default};
