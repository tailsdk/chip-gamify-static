const e=""+new URL("../assets/z3-built.worker.B9JmpgQQ.js",import.meta.url).href;export{e as default};
