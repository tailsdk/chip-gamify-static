import{a as t}from"../chunks/entry.DgS1pE1i.js";export{t as start};
